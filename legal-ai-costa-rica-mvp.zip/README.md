# Legal AI Costa Rica — MVP inicial

Este es un **prototipo funcional de interfaz + backend local** para aprender y validar el flujo:
- Interfaz web estática (se puede publicar en GitHub Pages).
- Backend FastAPI separado.
- Carga de archivos TXT, PDF y DOCX al backend.
- Extracción de texto y fragmentación.
- Recuperación inicial por palabras clave (RAG básico).
- El chat devuelve fragmentos recuperados, **no inventa una respuesta jurídica generada por IA**.

## Limitaciones importantes
- No consulta SINALEVI, Nexus PJ, Corte IDH ni otras fuentes externas.
- No usa todavía un modelo de IA ni embeddings semánticos.
- Los documentos se guardan en memoria del backend: se pierden al reiniciar.
- No hay autenticación ni separación de usuarios. **No cargue expedientes reales ni datos confidenciales.**
- El frontend de GitHub Pages no debe usarse para SaaS comercial ni para recibir información sensible. Consulte las políticas de GitHub Pages.
- El backend permite CORS desde cualquier origen solo para facilitar pruebas. Antes de desplegar, restrínjalo al dominio del frontend.

## Estructura
- `frontend/index.html`, `styles.css`, `app.js`: interfaz.
- `backend/main.py`: API y recuperación básica.
- `backend/requirements.txt`: dependencias.

## Paso 1 — Publicar la interfaz en GitHub Pages
1. Cree un repositorio público nuevo, por ejemplo `legal-ai-costa-rica`.
2. Suba **el contenido de la carpeta `frontend`** a la raíz del repositorio (index.html debe quedar en la raíz).
3. Abra **Settings → Pages**.
4. En **Build and deployment**, seleccione **Deploy from a branch**.
5. Seleccione `main` y `/ (root)` y guarde.
6. Espere a que GitHub publique la página.

La interfaz se abrirá, pero mostrará que el backend no está configurado hasta que lo conecte.

## Paso 2 — Ejecutar el backend en su computadora
Requiere Python 3.10 o posterior.

En una terminal, entre en la carpeta `backend` y ejecute:

```bash
python -m venv .venv
```

Activar entorno:
- Windows: `.venv\Scripts\activate`
- macOS/Linux: `source .venv/bin/activate`

Instalar dependencias e iniciar:
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

API disponible en `http://127.0.0.1:8000`; documentación interactiva en `http://127.0.0.1:8000/docs`.

**Nota:** una web publicada en internet no puede acceder a `127.0.0.1` de la computadora de quien la visita. Para probar frontend + backend en la misma computadora, abra `frontend/index.html` en el navegador y deje el backend ejecutándose. En el campo “URL del backend” use `http://127.0.0.1:8000`.

## Paso 3 — Conectar frontend y backend
En el panel de la interfaz, escriba la URL del backend y pulse “Guardar conexión”. Para una prueba local use:
`http://127.0.0.1:8000`

## Cómo probar
1. Inicie el backend.
2. Abra `frontend/index.html`.
3. Configure la URL del backend.
4. Cargue un archivo pequeño TXT, PDF o DOCX.
5. Escriba una pregunta relacionada con el documento.
6. El sistema mostrará los fragmentos recuperados y sus nombres de archivo.

Si no se encuentran fragmentos, el sistema lo informa. No presenta una consulta externa ni una verificación legal como realizada.

## Próximas fases antes de uso real
1. Añadir autenticación, autorización y almacenamiento privado persistente.
2. Restringir CORS, validar tipos/tamaño de archivo y aplicar límites de uso.
3. Añadir búsqueda híbrida/embeddings y un modelo de IA con citas ligadas a fragmentos.
4. Añadir conectores autorizados a fuentes jurídicas oficiales.
5. Añadir pruebas de seguridad, privacidad y evaluación de exactitud jurídica.
