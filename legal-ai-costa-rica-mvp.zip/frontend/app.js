// Interfaz de prueba. No contiene claves ni simula conexiones jurídicas oficiales.
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let backendUrl = localStorage.getItem("legalAiBackendUrl") || "http://127.0.0.1:8000";
$("#backend-url").value = backendUrl;
$("#save-backend").addEventListener("click", async () => {
  const candidate = $("#backend-url").value.trim().replace(/\/+$/, "");
  if (!candidate) { setConnection(false, "Ingrese la URL del backend"); return; }
  backendUrl = candidate;
  localStorage.setItem("legalAiBackendUrl", backendUrl);
  const ok = await checkBackend();
  if (ok) { $("#save-backend").textContent = "Conectado ✓"; }
  else { $("#save-backend").textContent = "Reintentar"; }
});
let selectedFiles = [];

function setConnection(ok, message) {
  $("#connection-status").textContent = message;
  $(".status-dot").style.background = ok ? "#22c55e" : "#eab308";
}
async function api(path, options={}) {
  const url = backendUrl.replace(/\/+$/, "") + path;
  const response = await fetch(url, options);
  if (!response.ok) {
    let detail = `Error HTTP ${response.status}`;
    try { const body = await response.json(); detail = body.detail || detail; } catch {}
    throw new Error(detail);
  }
  return response.json();
}
async function checkBackend() {
  try {
    const data = await api("/health");
    setConnection(true, data.status === "ok" ? "Backend conectado" : "Backend responde");
    return true;
  } catch {
    setConnection(false, "Backend sin conexión");
    return false;
  }
}
function showView(name) {
  $$(".view").forEach(v => v.classList.add("hidden"));
  $("#view-" + name).classList.remove("hidden");
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === name));
  $("#page-title").textContent = ({chat:"Chat jurídico",library:"Mi biblioteca",sources:"Fuentes jurídicas"})[name];
  if (name === "library") loadDocuments();
}
$$(".nav-item").forEach(b => b.addEventListener("click", () => showView(b.dataset.view)));

function addMessage(text, type="assistant", sources=[]) {
  const wrap = document.createElement("div");
  wrap.className = "message " + type;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = type === "assistant" ? "L" : "Tú";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const label = document.createElement("strong");
  label.textContent = type === "assistant" ? "Legal AI · Recuperación documental" : "Tu consulta";
  const p = document.createElement("p");
  p.textContent = text;
  bubble.append(label, p);
  if (sources.length) {
    const list = document.createElement("ul");
    sources.forEach(s => {
      const li = document.createElement("li");
      const strong = document.createElement("strong");
      strong.textContent = `${s.filename} — fragmento ${s.chunk_index + 1}`;
      const content = document.createElement("p");
      content.textContent = s.text;
      li.append(strong, content);
      list.append(li);
    });
    bubble.append(list);
    const small = document.createElement("small");
    small.textContent = "Estos son fragmentos recuperados, no una opinión jurídica verificada ni una respuesta generada por un modelo de IA.";
    bubble.append(small);
  }
  wrap.append(avatar, bubble);
  $("#messages").append(wrap);
  wrap.scrollIntoView({behavior:"smooth", block:"nearest"});
}
$("#chat-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const question = $("#question").value.trim();
  if (!question) return;
  addMessage(question, "user");
  $("#question").value = "";
  if (!(await checkBackend())) {
    addMessage("No se pudo procesar la consulta porque el backend no está conectado. No se ha realizado una búsqueda ni se ha generado una respuesta jurídica.");
    return;
  }
  try {
    const result = await api("/query", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({question, top_k:5})
    });
    if (!result.results.length) {
      addMessage("No se encontraron fragmentos relacionados en los documentos indexados. Esto no significa que no exista legislación o jurisprudencia aplicable. No se consultaron fuentes externas.");
    } else {
      addMessage(`Se recuperaron ${result.results.length} fragmentos de documentos cargados. Pregunta: ${question}`, "assistant", result.results);
    }
  } catch (error) {
    addMessage("La búsqueda falló: " + error.message + ". No se ha verificado ninguna fuente jurídica externa.");
  }
});
$("#file-input").addEventListener("change", (e) => {
  selectedFiles = [...e.target.files];
  $("#selected-files").textContent = selectedFiles.length ? selectedFiles.map(f => `${f.name} (${Math.ceil(f.size/1024)} KB)`).join(", ") : "Ningún archivo seleccionado";
  $("#upload-button").disabled = !selectedFiles.length;
});
$("#upload-button").addEventListener("click", async () => {
  if (!selectedFiles.length) return;
  if (!(await checkBackend())) {
    $("#upload-status").textContent = "Backend sin conexión. Los archivos no se han subido.";
    return;
  }
  const button = $("#upload-button");
  button.disabled = true; button.textContent = "Procesando...";
  const form = new FormData();
  selectedFiles.forEach(f => form.append("files", f));
  try {
    const result = await api("/documents", {method:"POST", body:form});
    $("#upload-status").textContent = `Procesados: ${result.documents.map(d=>d.filename).join(", ")}.`;
    selectedFiles = []; $("#file-input").value = ""; $("#selected-files").textContent = "Ningún archivo seleccionado";
    await loadDocuments();
  } catch (error) {
    $("#upload-status").textContent = "No se completó la carga: " + error.message;
  } finally {
    button.disabled = !selectedFiles.length; button.textContent = "Subir e indexar documentos";
  }
});
async function loadDocuments() {
  const target = $("#documents-list");
  try {
    const result = await api("/documents");
    target.replaceChildren();
    if (!result.documents.length) {
      const empty = document.createElement("div"); empty.className="empty-state"; empty.textContent="Todavía no hay documentos indexados."; target.append(empty); return;
    }
    result.documents.forEach(doc => {
      const card=document.createElement("div"); card.className="doc-card";
      const icon=document.createElement("div"); icon.className="doc-icon"; icon.textContent=doc.filename.split(".").pop().toUpperCase();
      const info=document.createElement("div"); info.className="doc-info";
      const strong=document.createElement("strong"); strong.textContent=doc.filename;
      const small=document.createElement("small"); small.textContent=`${doc.chunk_count} fragmentos · ${doc.char_count.toLocaleString()} caracteres`;
      info.append(strong,small); card.append(icon,info); target.append(card);
    });
  } catch {
    target.innerHTML = '<div class="empty-state">No se puede consultar la biblioteca: backend sin conexión.</div>';
  }
}
$("#refresh-docs").addEventListener("click", loadDocuments);

checkBackend();
