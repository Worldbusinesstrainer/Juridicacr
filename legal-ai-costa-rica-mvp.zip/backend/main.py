from __future__ import annotations

import io
import re
import hashlib
from typing import List

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pypdf import PdfReader
from docx import Document

app = FastAPI(
    title="Legal AI Costa Rica — API MVP",
    description=(
        "Prototipo de recuperación documental. No consulta fuentes oficiales "
        "y no genera opiniones jurídicas mediante un modelo de IA."
    ),
    version="0.1.0",
)

# SOLO PARA DESARROLLO LOCAL. En despliegue real, restringir al dominio exacto.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# Almacenamiento temporal en memoria: se borra al reiniciar el proceso.
DOCUMENTS: dict[str, dict] = {}
MAX_FILE_SIZE = 10 * 1024 * 1024
ALLOWED_EXTENSIONS = {".txt", ".pdf", ".docx"}


class QueryRequest(BaseModel):
    question: str = Field(min_length=2, max_length=2000)
    top_k: int = Field(default=5, ge=1, le=10)


def extract_text(filename: str, content: bytes) -> str:
    lower = filename.lower()
    try:
        if lower.endswith(".txt"):
            return content.decode("utf-8-sig", errors="replace")
        if lower.endswith(".pdf"):
            reader = PdfReader(io.BytesIO(content))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        if lower.endswith(".docx"):
            doc = Document(io.BytesIO(content))
            parts = [p.text for p in doc.paragraphs if p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    parts.append(" | ".join(cell.text for cell in row.cells))
            return "\n".join(parts)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"No se pudo leer {filename}: {exc}") from exc
    raise HTTPException(status_code=400, detail="Formato no admitido. Use TXT, PDF o DOCX.")


def chunk_text(text: str, size: int = 900, overlap: int = 120) -> list[str]:
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + size, len(text))
        chunks.append(text[start:end])
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks


def terms(text: str) -> set[str]:
    # Recuperación lexical sencilla, no embeddings ni comprensión jurídica.
    return {t for t in re.findall(r"[a-záéíóúüñ0-9]{3,}", text.lower())}


@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "Legal AI Costa Rica API",
        "mode": "keyword-retrieval-prototype",
        "official_sources_connected": False,
        "language_model_connected": False,
    }


@app.post("/documents")
async def upload_documents(files: List[UploadFile] = File(...)):
    processed = []
    for file in files:
        filename = (file.filename or "").replace("\\", "/").split("/")[-1]
        extension = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if extension not in ALLOWED_EXTENSIONS:
            raise HTTPException(status_code=400, detail=f"{filename}: formato no admitido.")
        content = await file.read()
        if len(content) > MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail=f"{filename}: supera el límite de 10 MB.")
        if not content:
            raise HTTPException(status_code=400, detail=f"{filename}: archivo vacío.")
        text = extract_text(filename, content)
        if not text.strip():
            raise HTTPException(
                status_code=422,
                detail=f"{filename}: no se pudo extraer texto. Si es un PDF escaneado, hará falta OCR.",
            )
        chunks = chunk_text(text)
        digest = hashlib.sha256(content).hexdigest()
        DOCUMENTS[digest] = {
            "filename": filename,
            "sha256": digest,
            "char_count": len(text),
            "chunks": chunks,
        }
        processed.append({
            "filename": filename,
            "char_count": len(text),
            "chunk_count": len(chunks),
            "sha256": digest,
        })
    return {"documents": processed, "storage": "memory_only"}


@app.get("/documents")
def list_documents():
    return {
        "documents": [
            {
                "filename": doc["filename"],
                "char_count": doc["char_count"],
                "chunk_count": len(doc["chunks"]),
                "sha256": doc["sha256"],
            }
            for doc in DOCUMENTS.values()
        ],
        "storage": "memory_only",
    }


@app.post("/query")
def query_documents(request: QueryRequest):
    question_terms = terms(request.question)
    if not question_terms:
        return {
            "question": request.question,
            "results": [],
            "method": "keyword_overlap",
            "message": "La pregunta no contiene términos suficientes para buscar.",
        }

    ranked = []
    for doc in DOCUMENTS.values():
        for index, chunk in enumerate(doc["chunks"]):
            chunk_terms = terms(chunk)
            overlap = question_terms.intersection(chunk_terms)
            if not overlap:
                continue
            # Puntuación simple: número de términos distintos coincidentes.
            score = len(overlap) / max(len(question_terms), 1)
            ranked.append({
                "filename": doc["filename"],
                "chunk_index": index,
                "text": chunk,
                "matched_terms": sorted(overlap),
                "score": round(score, 4),
            })
    ranked.sort(key=lambda item: (item["score"], len(item["matched_terms"])), reverse=True)
    return {
        "question": request.question,
        "results": ranked[:request.top_k],
        "method": "keyword_overlap",
        "is_ai_generated_answer": False,
        "official_sources_consulted": False,
    }
